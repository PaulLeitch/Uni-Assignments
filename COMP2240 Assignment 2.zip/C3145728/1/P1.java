/*
Name: Paul Leitch
Student Number: C3145728
Course: COMP2240 Assignment 2 Part 1
*/

import java.io.*;
import java.util.*;

public class P1 {
    public static void main(String[] args) throws InterruptedException {
        // Checks if there were any command line arguments given
        if (args.length < 1) {
            System.out.println("No file was specified");
            System.exit(1);
        }
        try {
            // Finds the file given as an argument and opens it
            File file = new File(args[0]);
            Scanner sc = new Scanner(file);
            // Create an instance of the bridge class
            Bridge bridge = new Bridge();

            int north = 0, south = 0;
            String line;
            // Hardcoded the value '2' as we know there are only 2 values to get, 'north'
            // and 'south'
            String[] lineArray = new String[2];
            while (sc.hasNextLine()) {
                // Grabs the line from the file
                line = sc.nextLine();
                // Splits the line into 2 sections for north and south farmers
                lineArray = line.split(", ");
                // Checks the first element in lineArray to see if it is for the north or south
                // farmer
                if (lineArray[0].charAt(0) == 'N') {
                    // Split the first value in the array into smaller parts. Ex 'N=2' will become
                    // 'N' and '2'
                    String segments[] = lineArray[0].split("=");
                    // Assign the integer value of the string into the variable
                    north = Integer.parseInt(segments[segments.length - 1]);
                } else {
                    String segments[] = lineArray[0].split("=");
                    south = Integer.parseInt(segments[segments.length - 1]);
                }
                // Checks the second element in lineArray to see if it is for the north or south
                // farmer
                if (lineArray[1].charAt(0) == 'N') {
                    String segments[] = lineArray[1].split("=");
                    north = Integer.parseInt(segments[segments.length - 1]);
                } else {
                    String segments[] = lineArray[1].split("=");
                    south = Integer.parseInt(segments[segments.length - 1]);
                }
            }
            // Close the file
            sc.close();

            bridge.bridgeStart(north, south);

        } catch (FileNotFoundException e) {
            // Throws an error if the file cannot be found
            System.out.println("File not found");
            System.exit(1);
        } catch (NumberFormatException e) {
            // Throws an error if the numbers are read in a strange order
            System.out.println("Something has gone wrong when trying to read the values");
            System.exit(1);
        }
    }
}