/*
Name: Paul Leitch
Student Number: C3145728
Course: COMP2240 Assignment 2 Part 1
*/

public class Neon {
    // Using static and volatile variable declarations to ensure that all threads
    // can access the variable and prevent them from caching the copied variable
    private static volatile int neon = 0;

    // Using synchronized methods to prevent memory inconsistency errors
    public synchronized void increment() {
        neon++;
    }

    public synchronized int value() {
        return neon;
    }
}