/*
Name: Paul Leitch
Student Number: C3145728
Course: COMP2240 Assignment 2 Part 1
*/

import java.util.concurrent.*;

public class Bridge extends Thread implements Runnable {
    // Semaphore used to manage threads
    private Semaphore sem = new Semaphore(1);

    // Empty default constructor
    public Bridge() {

    }

    // Custom constructor for setting the name of the thread and applying its
    // semaphore
    public Bridge(String s, Semaphore sem) {
        super(s);
        this.sem = sem;
    }

    // Method is run when thread is created
    public void run() {
        // Create an instance of the Neon class, used for keeping track of the amount of
        // farmers that have crossed the bridge
        Neon neon = new Neon();
        // Counter to track the number of times a farmer has crossed the bridge
        int count = 0;
        // Starting positions of the farmers
        if (Thread.currentThread().getName().charAt(0) == 'N') {
            threadMessage("Waiting for bridge. Going towards South");
        } else {
            threadMessage("Waiting for bridge. Going towards North");
        }
        // Loop to have the farmers walk the bridge
        while (true) {
            try {
                // Stops all other farmers from crossing the bridge
                sem.acquire();
                // Farmer crosses the bridge, with 200 milliseconds between every 5 steps
                Thread.sleep(200);
                threadMessage("Crossing bridge step 5");
                Thread.sleep(200);
                threadMessage("Crossing bridge step 10");
                Thread.sleep(200);
                threadMessage("Crossing bridge step 15");
                Thread.sleep(200);
                threadMessage("Across the bridge");
                Thread.sleep(200);
                count++;
                // Other farmers are now allowed to cross the bridge
                sem.release();
            } catch (InterruptedException e) {

            }
            // Increment and print the neon sign
            neon.increment();
            System.out.println("NEON = " + neon.value());

            // Check if the farmer is from the north or south island and see how many times
            // they have crossed the bridge, if the number is even they are heading in their
            // original direction, if the number is odd they are heading in the opposite
            // direction
            // There is probably a more elegant solution for this instead of just brute
            // forcing my way through it, but I couldnt think of one
            if (Thread.currentThread().getName().charAt(0) == 'N' && count % 2 == 0) {
                threadMessage("Waiting for bridge. Going towards South");
            } else if (Thread.currentThread().getName().charAt(0) == 'N' && count % 2 != 0) {
                threadMessage("Waiting for bridge. Going towards North");
            } else if (Thread.currentThread().getName().charAt(0) == 'S' && count % 2 == 0) {
                threadMessage("Waiting for bridge. Going towards North");
            } else if (Thread.currentThread().getName().charAt(0) == 'S' && count % 2 != 0) {
                threadMessage("Waiting for bridge. Going towards South");
            }
        }
    }

    public void bridgeStart(int n, int s) throws InterruptedException {
        // For loop to generate all of the threads for the farmers from the north
        for (int i = 0; i < n; i++) {
            new Bridge("N_Farmer" + (i + 1), sem).start();
        }
        // For loop to generate all of the threads for the farmers from the south
        for (int j = 0; j < s; j++) {
            new Bridge("S_Farmer" + (j + 1), sem).start();
        }
    }

    // Method that handles all of the printing to the screen
    static void threadMessage(String message) {
        String threadName = Thread.currentThread().getName();
        System.out.format("%s: %s%n", threadName, message);
    }
}