/*
Name: Paul Leitch
Student Number: C3145728
Course: COMP2240 Assignment 2 Part 2
*/

import java.io.*;
import java.util.*;

public class P2 {
    public static void main(String[] args) throws InterruptedException {
        // Checks if there were any command line arguments given
        if (args.length < 1) {
            System.out.println("No file was specified");
            System.exit(1);
        }
        try {
            // Finds the file given as an argument and opens it
            File file = new File(args[0]);
            // Open 2 instances of the file. One to count the total number of lines, and the
            // other to grab all of the information
            Scanner sc = new Scanner(file);
            Scanner sn = new Scanner(file);
            // Create an instance of the restaurant class
            Restaurant rest = new Restaurant();

            int answer = 0;
            // While loop that counts the total number of lines in the file. This number is
            // then used for size of the following arrays
            while (sn.hasNextLine()) {
                sn.nextLine();
                answer++;
            }
            // Close the first file
            sn.close();

            int i = 0;
            // Arrays to hold all of the customers eating details
            // Using 'answer - 1' because there is one more line in the file than customers
            int[] arrivalTime = new int[answer - 1];
            String[] customerID = new String[answer - 1];
            int[] eatingTime = new int[answer - 1];
            String line;
            // Hardcoded the value '3' as we know there is only 3 values that we need to get
            // from the file 'arrival time', 'customer ID', and 'eating time'
            String[] lineArray = new String[3];

            while (sc.hasNextLine()) {
                // Get the line from the file
                line = sc.nextLine();
                // Cancel out of the loop when the scanner reaches the last line
                if (line.equals("END")) {
                    break;
                }
                // Split the line into sections whenever an '=' is encountered
                lineArray = line.split(" ");
                // Input data into the arrays
                arrivalTime[i] = Integer.parseInt(lineArray[0]);
                customerID[i] = lineArray[1];
                eatingTime[i] = Integer.parseInt(lineArray[2]);
                i++;
            }
            // Close the second file
            sc.close();

            rest.restaurantStart(arrivalTime, customerID, eatingTime, (answer - 1));
        } catch (FileNotFoundException e) {
            // Throws an error if the file cannot be found
            System.out.println("File not found");
            System.exit(1);
        } catch (NumberFormatException e) {
            // Throws an error if the numbers are read in a strange order
            System.out.println("Something has gone wrong when trying to read the values");
            System.exit(1);
        }
    }
}