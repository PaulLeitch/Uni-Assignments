/*
Name: Paul Leitch
Student Number: C3145728
Course: COMP2240 Assignment 2 Part 2
*/

import java.util.concurrent.*;

public class Restaurant extends Thread implements Runnable {
    // Semaphore used to manage threads
    // Dont know why setting it to 6 works, you would think having it at 5 for 5
    // customers makes sence but apparently not
    private Semaphore sem = new Semaphore(6, true);
    // We gain the values for arrivalTime and eatingTime from the file
    // waitTime = MAX(eatingTime - arrivalTime)
    // seatingTime = waitingTime - cleaning time(5 minutes) (only for people who
    // turned up before cleaning time)
    private int arrivalTime, eatingTime, waitTime, seatingTime;

    // Empty default constructor
    public Restaurant() {

    }

    // Custom constructor for applying the neccesary data to the threads
    public Restaurant(int a, String c, int e, int w, Semaphore sem) {
        super(c);
        this.arrivalTime = a;
        this.eatingTime = e;
        this.sem = sem;
        this.seatingTime = a;
        this.waitTime = w;
    }

    // Method is run when thread is created
    public void run() {
        try {
            // Acquire a permit from the semaphore
            sem.acquire();

            // Check if there are any available permits for the semaphore
            if (sem.availablePermits() == 0) {
                // If the customer arrives before the tables have been cleaned...
                if (arrivalTime < (waitTime + 5)) {
                    // ...Make them wait
                    seatingTime = (waitTime + 5);
                    // Only release a permit once all other permits have been taken
                    sem.release();
                } else {
                    sem.release();
                }
            }
        } catch (InterruptedException e) {

        }

        // Print out the information for the customers
        System.out.printf("\n%-9s%-8d%-6d%-6d", Thread.currentThread().getName(), arrivalTime, seatingTime,
                (seatingTime + eatingTime));
    }

    public void restaurantStart(int arrive[], String customer[], int eat[], int arraySize) throws InterruptedException {
        // Create an array to hold the waiting times of all the customers
        int waitingTime[] = new int[arraySize];
        waitTime = findWaitingTime(waitingTime, arrive, eat, arraySize);
        // Print the headings
        System.out.printf("\n%-9s%-8s%-6s%-6s", "Customer", "Arrives", "Seats", "Leaves");

        // For loop to generate all of the threads for the customers
        for (int i = 0; i < arraySize; i++) {
            new Restaurant(arrive[i], customer[i], eat[i], waitTime, sem).start();
            // Tells the main thread to sleep for 10 milliseconds in order for each customer
            // thread to calculate and print in the desired order
            Thread.currentThread().sleep(10);
        }
    }

    public int findWaitingTime(int wt[], int a[], int e[], int size) {
        // For loop to fill the waiting time array
        for (int i = 0; i < size; i++) {
            wt[i] = e[i] - a[i];
        }

        int max = wt[0];
        // For loop to find the largest waiting time value
        for (int i = 0; i < size; i++) {
            if (wt[i] > max) {
                max = wt[i];
            }
        }

        return max;
    }
}