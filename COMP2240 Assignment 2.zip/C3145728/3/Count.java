/*
Name: Paul Leitch
Student Number: C3145728
Course: COMP2240 Assignment 2 Part 3
*/

public class Count {
    // Using static and volatile variable declarations to ensure that all threads
    // can access the variable and prevent them from caching the copied variable
    private static volatile int count = 5;

    // Using synchronized methods to prevent memory inconsistency errors
    public synchronized void increment() {
        count++;
    }

    public synchronized void decrement() {
        count--;
    }

    public synchronized int value() {
        return count;
    }
}