/*
Name: Paul Leitch
Student Number: C3145728
Course: COMP2240 Assignment 2 Part 3
*/

import java.util.concurrent.*;

public class Restaurant extends Thread implements Runnable {
    // arrivalTime and eatingTime are gotten from the file
    // waitTime = MAX(eatingTime - arrivalTime)
    // seatingTime = waitTime + cleaning time(5 minutes)
    private int arrivalTime, eatingTime, waitTime, seatingTime;

    // Empty default constructor
    public Restaurant() {

    }

    // Custom constructor for applying the neccesary data to the threads
    public Restaurant(int a, String c, int e, int w) {
        super(c);
        this.arrivalTime = a;
        this.eatingTime = e;
        this.seatingTime = a;
        this.waitTime = w;
    }

    // Method is run when thread is created
    public synchronized void run() {
        // Create an instance of the count class
        Count counter = new Count();
        // The counter acts as the monitor, incrementing/decrementing as the permits are
        // used
        counter.decrement();

        if (counter.value() < 0) {
            // If the customer arrives while all seats are taken...
            if (arrivalTime < (waitTime + 5)) {
                // ... Make them wait
                seatingTime = (waitTime + 5);
                // Only release a permit once all the others are taken
                counter.increment();
            } else {
                counter.increment();
            }
        }

        // Print out the information for the customers
        System.out.printf("\n%-9s%-8d%-6d%-6d", Thread.currentThread().getName(), arrivalTime, seatingTime,
                (seatingTime + eatingTime));
    }

    public void restaurantStart(int arrive[], String customer[], int eat[], int arraySize) throws InterruptedException {
        int waitingTime[] = new int[arraySize];
        waitTime = findWaitingTime(waitingTime, arrive, eat, arraySize);
        // Print the headings
        System.out.printf("\n%-9s%-8s%-6s%-6s", "Customer", "Arrives", "Seats", "Leaves");

        // For loop to generate all of the threads for the customers
        for (int i = 0; i < arraySize; i++) {
            new Restaurant(arrive[i], customer[i], eat[i], waitTime).start();
            // Tells the main thread to sleep for 10 milliseconds so that the other customer
            // threads can print in the desired order
            Thread.currentThread().sleep(10);
        }
    }

    public int findWaitingTime(int wt[], int a[], int e[], int size) {
        // For loop to fill the waiting time array
        for (int i = 0; i < size; i++) {
            wt[i] = e[i] - a[i];
        }

        int max = wt[0];
        // For loop to find the largest waiting time value
        for (int i = 0; i < size; i++) {
            if (wt[i] > max) {
                max = wt[i];
            }
        }

        return max;
    }
}